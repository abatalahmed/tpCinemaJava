package metier;

public class Film {
	
	
	
	private String titre, realisateur;

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getRealisateur() {
		return realisateur;
	}

	public void setRealisateur(String realisateur) {
		this.realisateur = realisateur;
	}

	public Film(String titre, String realisateur) {
		super();
		this.titre = titre;
		this.realisateur = realisateur;
	}
	
	
	

}
