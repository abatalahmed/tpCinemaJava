package metier;

public class SalleVip  extends Salle{

	
	
	
	public SalleVip(int numero, int nbPlaces, String nom) {
		super(numero, nbPlaces, nom);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculerPrix() {
		return 60;
	}
	

}
