package metier;

public class SalleNormale  extends Salle{

	
	
	
	public SalleNormale(int numero, int nbPlaces, String nom) {
		super(numero, nbPlaces, nom);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculerPrix() {
		// TODO Auto-generated method stub
		return 30;
	}

}
