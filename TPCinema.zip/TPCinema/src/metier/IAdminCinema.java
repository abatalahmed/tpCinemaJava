package metier;

public interface IAdminCinema {
	
	
	
	public void ajouterFilm(Film f);
	public void ajouterSalle(Salle s);
	public void ajouterSeance(Seance s);
	public double consulterCA();
	public double consulterTauxRemplissage(String titre);
	public void chargerFile(String chemin);
	public void Serialiser(String chemin);
	
	

}
