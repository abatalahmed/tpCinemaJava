/**
 * 
 */
/**
 * 
 */
module TPCinema {
	requires java.desktop;
}