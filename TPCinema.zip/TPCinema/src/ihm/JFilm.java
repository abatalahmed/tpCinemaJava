package ihm;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import metier.Cinema;
import metier.Film;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JFilm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtTitre;
	private JTextField txtRealisateur;
	
	private Cinema cinema;
	private JTable tableFilm;
	private FilmModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFilm frame = new JFilm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JFilm() {
		
		cinema=new Cinema();
		model=new FilmModel();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Titre");
		lblNewLabel.setBounds(42, 19, 61, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblRealisateur = new JLabel("Realisateur");
		lblRealisateur.setBounds(256, 19, 61, 16);
		contentPane.add(lblRealisateur);
		
		txtTitre = new JTextField();
		txtTitre.setBounds(30, 47, 130, 26);
		contentPane.add(txtTitre);
		txtTitre.setColumns(10);
		
		txtRealisateur = new JTextField();
		txtRealisateur.setColumns(10);
		txtRealisateur.setBounds(256, 47, 130, 26);
		contentPane.add(txtRealisateur);
		
		JButton btnNewButton = new JButton("Ajouter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cinema.ajouterFilm(new Film(txtTitre.getText(), txtRealisateur.getText()));
				model.setData(cinema.consulterFilms());
				txtTitre.setText("");
				txtRealisateur.setText("");
			}
		});
		btnNewButton.setBounds(303, 83, 117, 29);
		contentPane.add(btnNewButton);
		
		cinema.chargerFile("films.txt");
		model.setData(cinema.consulterFilms());
		tableFilm=new JTable(model);
		JScrollPane jspFilm = new JScrollPane(tableFilm);
		jspFilm.setBounds(42, 127, 374, 125);
		contentPane.add(jspFilm);
	}
}
